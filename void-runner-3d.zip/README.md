# Void Runner 3D

## Overview
- Void Runner 3D is a browser-friendly, 3D space dodging experience that runs entirely inside a single HTML file using Three.js, procedural audio, and localStorage for high-score persistence, while targeting smooth 60 FPS gameplay across desktop and mobile browsers.
- Players survive asteroid fields across three difficulty tiers, collect power-ups, and interact with a player-owned leaderboard so that the previous shared leaderboard model is no longer the live design and every score is tied to a registered handle.

## Installation

1. Open `index.html` in a current browser (Chrome, Firefox, Safari, Edge, or mobile equivalents) served through a static host or `file://` URI to experience the game client.
2. Make sure you have a local SpaceXpanse ROD node, so the relay can fulfill leaderboard requests via JSON-RPC.
3. Ensure the relay has access to the SpaceXpanse ROD node through the JSON-RPC server at `127.0.0.1:11999` by setting proper credentials configured in `spacexpanse.conf` and the .env file.
4. Start the leaderboard-relay.exe to enable game-node communication.
5. Start playing!

## N.B. 
Add these lines to your spacexpanse.conf file:
server=1
listen=1
discover=1
rpcuser=<YOURUSER>
rpcpassword=<YOURPASS>
rpcbind=127.0.0.1
rpcallowip=127.0.0.1
rpcport=11999

and then add these user and password to the .env file after renaming it from .env_example

YOU WILL NEED SOME ROD COINS IN YOUR WALLET TOO!

## Usage Guidelines
- At launch, navigate the menu to select Easy, Normal, or Hard difficulty, then tap Start to begin the asteroid-dodging run.
- During gameplay, collect shield and speed boost power-ups, survive waves of asteroids spawned via the delta-time loop, and monitor HUD elements such as timer, difficulty, and local best time.
- When the run ends, the overlay displays final score details and allows submitting results to the chain leaderboard through the relay, which keeps localStorage-based bests separate from on-chain top-ten data.
- Touch-friendly controls (keyboard, mouse, mobile touch) are supported, and the local relay reports statuses for chain and health endpoints to keep players informed of backend availability.
- Anti-cheat timer handling now auto-pauses gameplay when the tab loses focus or becomes hidden, and survival time no longer advances while paused/backgrounded.
- First-run users now start with an empty handle field instead of inheriting a seeded default name.
- During Game Over, unregistered players see an editable handle field plus Register guidance, while registered players see their locked handle and a Submit action.
- Submit only becomes available when the player is registered and the latest run beats that player's existing chain best for the selected difficulty.
- Duplicate handle attempts now return a clear “already taken” path so players can immediately choose another handle.

## Technical Details
- The browser client remains a single self-contained file ([`index.html`](index.html)) with inline markup, styling, and script so no build system is required; developers can open it directly or through any static host.
- Blockchain leaderboard handling runs through [`leaderboard-relay.js`](leaderboard-relay.js), which implements the player-owned leaderboard architecture rather than the old shared leaderboard table.
- The relay/API surface exposes health, registration, and per-player scoring endpoints: `GET /api/health`, `GET /api/player/status`, `POST /api/player/register`, `GET /api/leaderboard`, and `POST /api/leaderboard/submit`.
- Players must register before submitting scores; registration associates a handle namespace (`p/<handle>`) that the relay enforces for subsequent submissions, and each submitted score updates only that player’s own `g/voidrunner3d/<handle>/record` entry.
- Registration treats `handle` as the sole identifier, rejects duplicate handles with HTTP 409 to preserve uniqueness, and the UI only locks a handle after that exact handle is successfully registered.
- The client no longer auto-assumes a default player handle on first run, and failed status/register checks reset the UI back to an editable state instead of leaving stale lock state behind.
- Difficulty support remains `easy`, `normal`, and `hard`, and top-ten standings are derived by scanning/querying every `g/voidrunner3d/` record on-chain, aggregating the best scores per difficulty from registered players.
- The relay depends on Node.js 18+, forwards requests to the SpaceXpanse ROD JSON-RPC node, and preserves localStorage bests independently while writing top-ten data on-chain.
- Procedural audio uses Web Audio API, and Three.js r128 renders the 3D scene; local performance patterns follow a MENU → PLAYING → GAME_OVER → PAUSED state machine with object pooling for efficiency.
- Timer accounting uses active-play accumulation instead of a single wall-clock origin, so paused time and background-tab time are excluded from score progression.

## Contribution Guidelines
- Document all project changes in the `CHANGELOG.md`, describing new features, bugs, or next steps so future collaborators know the current state and documentation cadence.
- After each set of updates, add a timestamped, priority-aware entry to `CHANGELOG.md` so auditors can track modifications (`CHANGELOG.md`:1-8).
- Preserve the single-file nature of `index.html` unless a breaking change absolutely requires extra assets; keep gameplay and HUD logic tightly coupled and mention any external dependencies you introduce in both the tech and architecture memory bank files.
- Use described scripts and versions, and run `node leaderboard-relay.js` to verify the leaderboard relay before publishing any client-side changes (`package.json`:1-11).

## Changelog
- [`CHANGELOG.md`](CHANGELOG.md:1-8) describes the latest documentation-focused updates, including the refreshed memory bank context and the new changelog process.

## License
- No license file currently exists. Use this repository under the default rights granted by the owner until an explicit license is provided.
